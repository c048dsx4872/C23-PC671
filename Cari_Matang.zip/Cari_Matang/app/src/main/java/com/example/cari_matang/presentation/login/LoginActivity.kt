package com.example.cari_matang.presentation.login

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import com.example.cari_matang.databinding.ActivityLoginBinding
import com.example.cari_matang.presentation.main.MainActivity
import com.example.cari_matang.presentation.register.RegisterActivity
import com.example.cari_matang.utils.startActivity

class LoginActivity : AppCompatActivity() {
    private lateinit var binding: ActivityLoginBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityLoginBinding.inflate(layoutInflater)
        setContentView(binding.root)

        onAction()
    }

    private fun onAction() {
        binding.btnLogin.setOnClickListener { startActivity<MainActivity>() }

        binding.btnRegisterLogin.setOnClickListener { startActivity<RegisterActivity>() }
    }
}