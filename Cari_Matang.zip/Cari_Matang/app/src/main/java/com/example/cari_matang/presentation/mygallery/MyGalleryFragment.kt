package com.example.cari_matang.presentation.mygallery

import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.PopupMenu
import android.widget.Toast
import com.example.cari_matang.R
import com.example.cari_matang.presentation.mygallery.MyGalleryAdapter

import com.example.cari_matang.databinding.FragmentMyGalleryBinding


class MyGalleryFragment : Fragment() {

    private var _binding: FragmentMyGalleryBinding? = null
    private val binding get() = _binding!!
    private lateinit var myGalleryAdapter: MyGalleryAdapter

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        _binding = FragmentMyGalleryBinding.inflate(inflater, container, false)
        return _binding?.root
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        myGalleryAdapter = MyGalleryAdapter()

        /**
         * Initialize data
         */
        initMyGallery()
        onAction()
    }

    private fun onAction() {
        myGalleryAdapter.onClick {
            val popUpMenu = PopupMenu(context, it)
            popUpMenu.menuInflater.inflate(R.menu.config_gallery_menu, popUpMenu.menu)

            popUpMenu.setOnMenuItemClickListener {
                when(it.itemId){
                    R.id.action_edit -> {
                        Toast.makeText(context, "Edit", Toast.LENGTH_SHORT).show()
                        return@setOnMenuItemClickListener true
                    }

                    R.id.action_manage_photos -> {
                        Toast.makeText(context, "Manage Photos", Toast.LENGTH_SHORT).show()
                        return@setOnMenuItemClickListener true
                    }

                }
                return@setOnMenuItemClickListener false
            }

            popUpMenu.show()
        }
    }

    private fun initMyGallery() {
        binding.rvMyGallery.adapter = myGalleryAdapter
    }
}
