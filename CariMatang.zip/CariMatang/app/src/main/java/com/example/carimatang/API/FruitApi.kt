package com.example.carimatang.API

import com.example.carimatang.AnalyzeFruitResponse
import okhttp3.MediaType.Companion.toMediaTypeOrNull
import okhttp3.MultipartBody
import okhttp3.RequestBody
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory
import java.io.File

class FruitApi {
    private val retrofit = Retrofit.Builder()
        .baseUrl("https://your-api-url.com/")
        .addConverterFactory(GsonConverterFactory.create())
        .build()

    private val service = retrofit.create(FruitApiService::class.java)

    fun analyzeFruit(imageFilePath: String) {
        val imageFile = File(imageFilePath)
        val requestFile = RequestBody.create("multipart/form-data".toMediaTypeOrNull(), imageFile)
        val body = MultipartBody.Part.createFormData("image", imageFile.name, requestFile)

        val call = service.analyzeFruit(body)

        call.enqueue(object : Callback<AnalyzeFruitResponse> {
            override fun onResponse(call: Call<AnalyzeFruitResponse>, response: Response<AnalyzeFruitResponse>) {
                if (response.isSuccessful) {

                } else {

                }
            }

            override fun onFailure(call: Call<AnalyzeFruitResponse>, t: Throwable) {

            }
        })
    }
}
