package com.example.cari_matang.presentation.landing

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import com.example.cari_matang.R
import com.example.cari_matang.databinding.ActivityLandingBinding
import com.example.cari_matang.presentation.login.LoginActivity
import com.example.cari_matang.utils.startActivity

class LandingActivity : AppCompatActivity() {

    private lateinit var binding : ActivityLandingBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityLandingBinding.inflate(layoutInflater)
        setContentView(binding.root)


        onAction()
    }

    private fun onAction() {
        binding.btnLanding.setOnClickListener { startActivity<LoginActivity>() }
    }


}