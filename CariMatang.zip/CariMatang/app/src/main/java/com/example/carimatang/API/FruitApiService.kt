package com.example.carimatang.API

import com.example.carimatang.AnalyzeFruitResponse
import okhttp3.MultipartBody
import retrofit2.Call
import retrofit2.http.*

interface FruitApiService {
    @Multipart
    @POST("analyzeFruit")
    fun analyzeFruit(@Part image: MultipartBody.Part): Call<AnalyzeFruitResponse>
}