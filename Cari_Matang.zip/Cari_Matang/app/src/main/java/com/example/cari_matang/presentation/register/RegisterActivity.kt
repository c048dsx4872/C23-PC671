package com.example.cari_matang.presentation.register

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import androidx.activity.addCallback
import com.example.cari_matang.databinding.ActivityRegisterBinding
import com.example.cari_matang.utils.toast

class RegisterActivity : AppCompatActivity() {

    private lateinit var binding : ActivityRegisterBinding


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityRegisterBinding.inflate(layoutInflater)
        setContentView(binding.root)

        initActionBar()
        onAction()
    }

    private fun onAction() {
        binding.btnRegister.setOnClickListener { toast("Register") }

        binding.tbRegister.setNavigationOnClickListener {
            onBackPressedDispatcher.addCallback(this) {
                finish()
            }.handleOnBackPressed()
        }
    }

    private fun initActionBar() {
        setSupportActionBar(binding.tbRegister)
        supportActionBar?.setDisplayHomeAsUpEnabled(true)
        supportActionBar?.title = ""
    }
}