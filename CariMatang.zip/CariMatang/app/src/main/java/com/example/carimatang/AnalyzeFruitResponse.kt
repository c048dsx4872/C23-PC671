package com.example.carimatang

data class AnalyzeFruitResponse(
    val status: String,
    val fruit: String,
    val condition: String
)
