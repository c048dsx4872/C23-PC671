package com.example.cari_matang.presentation.home

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.example.cari_matang.databinding.ItemProductBinding

class RecommendProductAdapter : RecyclerView.Adapter<RecommendProductAdapter.ViewHolder>() {
    class ViewHolder(private val binding: ItemProductBinding) :
        RecyclerView.ViewHolder(binding.root) {
        fun bindItem(listener: ((String) -> Unit)?) {
            itemView.setOnClickListener {
                listener?.let {
                    it("")
                }
            }

        }

    }

    private var listener : ((String) -> Unit)? = null

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val layoutInflater = LayoutInflater.from(parent.context)
        val binding = ItemProductBinding.inflate(layoutInflater, parent, false)
        return ViewHolder(binding)

    }

    override fun getItemCount(): Int = 10


    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
     holder.bindItem(listener)
    }

    fun OnClick(listener : ((String) -> Unit)){
        this.listener = listener
    }
}
