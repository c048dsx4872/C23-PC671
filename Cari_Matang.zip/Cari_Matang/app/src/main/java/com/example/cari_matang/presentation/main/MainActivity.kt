package com.example.cari_matang.presentation.main

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import androidx.fragment.app.Fragment
import com.example.cari_matang.R
import com.example.cari_matang.databinding.ActivityMainBinding
import com.example.cari_matang.presentation.camera.CameraActivity
import com.example.cari_matang.presentation.home.HomeFragment
import com.example.cari_matang.presentation.mygallery.MyGalleryFragment
import com.example.cari_matang.presentation.user.UserFragment

class MainActivity : AppCompatActivity() {

    private lateinit var binding : ActivityMainBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        initBottomNav()
    }

    override fun onBackPressed() {
        val itemId = binding.btmNavMain.selectedItemId
        if (itemId == R.id.action_home){
            finish()
        }else{
            if (itemId == 0){
                openHomeFragment()
            }
            openHomeFragment()
        }
    }

    private fun initBottomNav() {
        binding.btmNavMain.setOnItemSelectedListener {
            when(it.itemId){
                R.id.action_home -> {
                    openFragment(HomeFragment())
                    return@setOnItemSelectedListener true
                }

                R.id.action_camera -> {
                    startActivity(Intent(this, CameraActivity::class.java))
                    return@setOnItemSelectedListener true
                }

                R.id.action_my_gallery-> {
                    openFragment(MyGalleryFragment())
                    return@setOnItemSelectedListener true
                }

                R.id.action_user -> {
                    openFragment(UserFragment())
                    return@setOnItemSelectedListener true
                }
            }
            return@setOnItemSelectedListener false
        }
        openHomeFragment()
    }

    private fun openHomeFragment() {
        binding.btmNavMain.selectedItemId = R.id.action_home
    }

    private fun openFragment(fragment: Fragment) {
        supportFragmentManager
            .beginTransaction()
            .replace(R.id.frame_main, fragment)
            .addToBackStack(null)
            .commit()
    }
}